Overwrite InputManager.asset and TagManager.asset under Unfinished Fantasy Project\ProjectSettings.
Manually set up layer according to the picture.
